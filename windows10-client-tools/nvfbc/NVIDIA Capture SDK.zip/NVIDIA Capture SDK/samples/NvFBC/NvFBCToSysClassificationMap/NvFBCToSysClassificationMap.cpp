/*!
 * \defgroup NvFBCToSysClassificationMap
 * \brief
 * Demonstrates the use of NvFBCToSys to copy the desktop to a system memory buffer and save it as a file. 
 * This sample demonstrates the use of NvFBCToSys class to record the
 * entire desktop. It covers loading the NvFBC DLL, loading the NvFBC 
 * function pointers, creating an instance of NvFBCToSys and using it 
 * to copy the full screen frame buffer into system memory.
 * This sample also demonstrates enabling NVFBC Image Area Classification Map feature
 *
 * \cond
 * \copyright
 * Copyright 1993-2018 NVIDIA Corporation.  All rights reserved.
 * NOTICE TO LICENSEE: This source code and/or documentation ("Licensed Deliverables")
 * are subject to the applicable NVIDIA license agreement
 * that governs the use of the Licensed Deliverables.
 */

#include <windows.h>
#include <stdio.h>
#include <Math.h>
#include <string>
#include <helper_string.h>
#include <Bitmap.h>

#include <NvFBCLibrary.h>
#include <NvFBC/nvFBCToSys.h>

// Structure to store the command line arguments
typedef struct _AppArguments
{
    int   iFrameCnt; // Number of frames to grab
    int   iStartX; // Grab start x coord
    int   iStartY; // Grab start y coord
    int   iWidth;  // Grab width
    int   iHeight; // Grab height
    int   iSetUpFlags; // Set up flags
    bool  bHWCursor;   // Grab hardware cursor
    DWORD dwStampWidth; //ClassificationMap stamp width
    DWORD dwStampHeight; //ClassificationMap stamp height
    NVFBCToSysGrabMode     eGrabMode;  // Grab mode
    NVFBCToSysBufferFormat eBufFormat; // Output buffer format
    std::string sBaseName; // Output file name
    _AppArguments()
        : iFrameCnt(0)
        , iStartX(0)
        , iStartY(0)
        , iWidth(0)
        , iHeight(0)
        , iSetUpFlags(0)
        , bHWCursor(false)
        , eGrabMode(NVFBC_TOSYS_SOURCEMODE_FULL)
        , eBufFormat(NVFBC_TOSYS_ARGB)
        , dwStampWidth(NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM)
        , dwStampHeight(NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM)
    {
        sBaseName.clear();
    }
} AppArguments;

// Prints the help message
void printHelp()
{
    printf("Usage: NvFBCToSysClassificationMap [options]\n");
    printf("  -frames frameCnt     The number of frames to grab\n");
    printf("                       this value defaults to one.\n");
    printf("                       If the value is greater than one, only the final frame is saved as a bitmap.\n");
    printf("  -scale width height  Scales the grabbed frame buffer\n");
    printf("                       to the provided width and height\n");
    printf("  -crop x y width height  Crops the grabbed frame buffer to\n");
    printf("                          the provided region\n");
    printf("  -grabCursor          Grabs the hardware cursor\n");
    printf("  -output              Output file name\n");
    printf("  -nowait              Grab with the no wait flag\n");
    printf("  -stampsize w h       w= stamp width; h = stamp height; Must be a multiple of \n");
    printf("                       NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM and less than\n");
    printf("                       NVFBC_TOSYS_MAX_CLASSIFICATION_MAP_STAMP_DIM\n ");
    printf("  -about               brief summary about this application\n");
}

// Parse the command line arguments
bool parseCmdLine(int argc, char **argv, AppArguments &args)
{
    args.iFrameCnt = 4;
    args.iStartX = 0;
    args.iStartY = 0;
    args.iWidth = 0;
    args.iHeight = 0;
    args.iSetUpFlags = NVFBC_TOSYS_NOFLAGS;
    args.bHWCursor = false;
    args.eGrabMode = NVFBC_TOSYS_SOURCEMODE_FULL;
    args.eBufFormat = NVFBC_TOSYS_ARGB;
    args.sBaseName = "NvFBCToSysClassificationMap";
    args.dwStampWidth = NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM;
    args.dwStampHeight = NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM;

    for(int cnt = 1; cnt < argc; ++cnt)
    {
        if(0 == STRCASECMP(argv[cnt], "-frames"))
        {
            if(cnt+1 >= argc)
            {
                printf("Missing -frames option\n");
                printHelp();
                return false;
            }

            args.iFrameCnt = atoi(argv[cnt+1]);

            // Must grab at least one frame.
            if(args.iFrameCnt < 1)
                args.iFrameCnt = 1;
            ++cnt;

        }
        else if(0 == STRCASECMP(argv[cnt], "-scale"))
        {
            if(NVFBC_TOSYS_SOURCEMODE_FULL != args.eGrabMode)
            {
                printf("Both -crop and -scale cannot be used at the same time.\n");
                printHelp();
                return false;
            }

            if((cnt + 2) > argc)
            {
                printf("Missing -scale options\n");
                printHelp();
                return false;
            }

            args.iWidth = atoi(argv[cnt+1]);
            args.iHeight = atoi(argv[cnt+2]);
            args.eGrabMode = NVFBC_TOSYS_SOURCEMODE_SCALE;

            cnt += 2;
        }
        else if(0 == STRCASECMP(argv[cnt], "-crop"))
        {
            if(NVFBC_TOSYS_SOURCEMODE_FULL != args.eGrabMode)
            {
                printf("Both -crop and -scale cannot be used at the same time.\n");
                printHelp();
                return false;
            }

            if((cnt + 4) >= argc)
            {
                printf("Missing -crop options\n");
                printHelp();
                return false;
            }

            args.iStartX = atoi(argv[cnt+1]);
            args.iStartY = atoi(argv[cnt+2]);
            args.iWidth = atoi(argv[cnt+3]);
            args.iHeight = atoi(argv[cnt+4]);
            args.eGrabMode = NVFBC_TOSYS_SOURCEMODE_CROP;

            cnt += 4;
        }
        else if(0 == STRCASECMP(argv[cnt], "-grabCursor"))
        {
            args.bHWCursor = true;
        }
        else if(0 == STRCASECMP(argv[cnt], "-nowait"))
        {
            args.iSetUpFlags |= NVFBC_TOSYS_NOWAIT;
        }
        else if(0 == STRCASECMP(argv[cnt], "-output"))
        {
            ++cnt;

            if(cnt >= argc)
            {
                printf("Missing -output option\n");
                printHelp();
                return false;
            }

            args.sBaseName = argv[cnt];
            args.sBaseName += ".bmp";
        }
        else if (0 == STRCASECMP(argv[cnt], "-stampsize"))
        {
            ++cnt;

            if (cnt >= argc)
            {
                printf("Missing -stampsize option\n");
                printHelp();
                return false;
            }

            args.dwStampWidth = atoi(argv[cnt]);
            ++cnt;
            args.dwStampHeight = atoi(argv[cnt]);

        }
        else if (0 == STRCASECMP(argv[cnt], "-about"))
        {
            printf("\tThis sample demonstrates the use of NvFBCToSys class to record the\n");
            printf("\tentire desktop. It covers loading the NvFBC DLL, loading the NvFBC\n");
            printf("\tfunction pointers, creating an instance of NvFBCToSys and using it\n");
            printf("\tto copy the full screen frame buffer into system memory.\n");
            printf("\tThis sample also demonstrates enabling NVFBC Image Area Classification Map feature.\n");
            printf("\tThe NVFBC Image Area Classification Map feature is enabled by default in this sample app.\n");
            printf("\tThe NVFBC Image Area Classification Map feature is supported for ARGB output format in this app.\n");
            printf("\tThe application uses default Classification Map stamp size of 16x16. Use -stampsize cmd option for custom stamp size .\n");
            return false;
        }
        else
        {
            printf("Unexpected argument %s\n", argv[cnt]);
            printHelp();
            return false;
        }
    }

    return true;
}
/*!
 * Main program
 */
int main(int argc, char* argv[])
{
    AppArguments args;

    NvFBCLibrary nvfbcLibrary;
    NvFBCToSys *nvfbcToSys = NULL;

    DWORD maxDisplayWidth = -1, maxDisplayHeight = -1;
    BOOL bRecoveryDone = FALSE;

    NvFBCFrameGrabInfo grabInfo;
    unsigned char *frameBuffer = NULL;
    unsigned char *classificationMap = NULL;

    char frameNo[10];
    std::string outName;
    
    if(!parseCmdLine(argc, argv, args))
        return -1;

    //! Load NvFBC
    if(!nvfbcLibrary.load())
    {
        fprintf(stderr, "Unable to load the NvFBC library\n");
        return -1;
    }

    //! Create an instance of NvFBCToSys
    nvfbcToSys = (NvFBCToSys *)nvfbcLibrary.create(NVFBC_TO_SYS, &maxDisplayWidth, &maxDisplayHeight);

    NVFBCRESULT status = NVFBC_SUCCESS;
    if(!nvfbcToSys)
    {
        fprintf(stderr, "Unable to create an instance of NvFBC\n");
        return -1;
    }

    //! Setup the frame grab
    NVFBC_TOSYS_SETUP_PARAMS fbcSysSetupParams = {0};
    fbcSysSetupParams.dwVersion = NVFBC_TOSYS_SETUP_PARAMS_VER;
    fbcSysSetupParams.eMode = args.eBufFormat;
    fbcSysSetupParams.bWithHWCursor = args.bHWCursor;
    fbcSysSetupParams.ppBuffer = (void **)&frameBuffer;
    fbcSysSetupParams.bClassificationMap = TRUE;                                   //set this field to enable Frame Classification feature
    fbcSysSetupParams.ppClassificationMap = (void **)&classificationMap;           //NvFBC allocates output buffer
    
    fbcSysSetupParams.dwClassificationMapStampWidth  = args.dwStampWidth;  
    fbcSysSetupParams.dwClassificationMapStampHeight = args.dwStampHeight;  
    
    status = nvfbcToSys->NvFBCToSysSetUp(&fbcSysSetupParams);
    if (status == NVFBC_SUCCESS)
    {
        //! Sleep so that ToSysSetUp forces a framebuffer update
        Sleep(100);
        
        NVFBC_TOSYS_GRAB_FRAME_PARAMS fbcSysGrabParams = {0};
        //! For each frame to grab..
        for(int cnt = 0; cnt < args.iFrameCnt; ++cnt)
        {
            _itoa_s(cnt, frameNo, 10, 10);
            outName = args.sBaseName + "_" + frameNo + ".bmp";
            //! Grab the frame.  
            // If scaling or cropping is enabled the width and height returned in the
            // NvFBCFrameGrabInfo structure reflect the current desktop resolution, not the actual grabbed size.
            fbcSysGrabParams.dwVersion = NVFBC_TOSYS_GRAB_FRAME_PARAMS_VER;
            fbcSysGrabParams.dwFlags = args.iSetUpFlags;
            fbcSysGrabParams.dwTargetWidth = args.iWidth;
            fbcSysGrabParams.dwTargetHeight = args.iHeight;
            fbcSysGrabParams.dwStartX = args.iStartX;
            fbcSysGrabParams.dwStartY = args.iStartY;
            fbcSysGrabParams.eGMode = args.eGrabMode;
            fbcSysGrabParams.pNvFBCFrameGrabInfo = &grabInfo;
        
            status = nvfbcToSys->NvFBCToSysGrabFrame(&fbcSysGrabParams);
            if (status == NVFBC_SUCCESS)
            {
                bRecoveryDone = FALSE;
                //! Dump Image Classification output
                if (classificationMap)
                {
                    //classificationMap output will always be 16x16 reduced irrespective of stampsize
                    long int iOutputWidth = (long int)ceil((float)grabInfo.dwWidth / NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM);
                    long int iTotalSize = (long int)(ceil((float)grabInfo.dwWidth / NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM)*ceil((float)grabInfo.dwHeight / NVFBC_TOSYS_MIN_CLASSIFICATION_MAP_STAMP_DIM));

                    FILE *fp = NULL;
                    errno_t err = fopen_s(&fp, "ClassificationMap.txt", cnt == 0 ? "wt" : "at");
                    fprintf(fp, "\n\nClassificationMap_%d :- \n", cnt);
                    for (int i = 0; i < iTotalSize; i++)
                    {
                        if (i%iOutputWidth == 0)
                        {
                            fprintf(fp, "\n%01x", (BYTE *)(classificationMap[i]));
                        }
                        else
                        {
                            fprintf(fp, "%01x", (BYTE *)(classificationMap[i]));
                        }
                    }
                    fclose(fp);
                }

                //! Save the frame to disk
                switch(args.eBufFormat)
                {
                case NVFBC_TOSYS_ARGB:
                    SaveARGB(outName.c_str(), frameBuffer, grabInfo.dwWidth, grabInfo.dwHeight, grabInfo.dwBufferWidth);
                    fprintf (stderr, "Grab succeeded. Wrote %s as ARGB.\n", outName.c_str() );
                    break;

                default:
                    fprintf (stderr, "Un-expected grab format %d.", args.eBufFormat);
                    break;
                }
            }
            else
            {
                if (bRecoveryDone == TRUE)
                {
                    fprintf(stderr, "Unable to recover from NvFBC Frame grab failure.\n");
                    goto quit;
                }
                
                if (status == NVFBC_ERROR_DYNAMIC_DISABLE)
                {
                    fprintf(stderr, "NvFBC disabled. Quitting\n");
                    goto quit;
                }

                if (status == NVFBC_ERROR_INVALIDATED_SESSION)
                {
                    fprintf(stderr, "Session Invalidated. Attempting recovery\n");
                    nvfbcToSys->NvFBCToSysRelease();
                    nvfbcToSys = NULL;
                    //! Recover from error. Create an instance of NvFBCToSys
                    nvfbcToSys = (NvFBCToSys *)nvfbcLibrary.create(NVFBC_TO_SYS, &maxDisplayWidth, &maxDisplayHeight);
                    if(!nvfbcToSys)
                    {
                        fprintf(stderr, "Unable to create an instance of NvFBC\n");
                        goto quit;
                    }
                    //! Setup the frame grab
                    NVFBC_TOSYS_SETUP_PARAMS fbcSysSetupParams = {0};
                    fbcSysSetupParams.dwVersion = NVFBC_TOSYS_SETUP_PARAMS_VER;
                    fbcSysSetupParams.eMode = args.eBufFormat;
                    fbcSysSetupParams.bWithHWCursor = args.bHWCursor;
                    fbcSysSetupParams.ppBuffer = (void **)&frameBuffer;
                    fbcSysSetupParams.bClassificationMap = TRUE;
                    fbcSysSetupParams.ppClassificationMap = (void **)&classificationMap;
                    fbcSysSetupParams.dwClassificationMapStampWidth = args.dwStampWidth;
                    fbcSysSetupParams.dwClassificationMapStampHeight = args.dwStampHeight;

                    status = nvfbcToSys->NvFBCToSysSetUp(&fbcSysSetupParams);
                    cnt--;
                    if (status == NVFBC_SUCCESS)
                    {
                        bRecoveryDone = TRUE;
                    }
                    else
                    {
                        fprintf(stderr, "Unable to recover from NvFBC Frame grab failure.\n");
                        goto quit;
                    }
                }
            }
        }
    }
    if (status != NVFBC_SUCCESS)
    {
        fprintf(stderr, "Unable to setup frame grab.\n");
    }

quit:
    if (nvfbcToSys)
    {
        //! Relase the NvFBCToSys object
        nvfbcToSys->NvFBCToSysRelease();
    }

    return 0;
}

/* !
* \endcond
*/