#include <d3d9.h>
#include <iostream>

using namespace std;

static void WINAPI SaveBmp(BYTE *pData, int nWidth, int nHeight, int nPitch, TCHAR *szFilePath) {
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = nWidth;
    bmi.bmiHeader.biHeight = nHeight;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    DWORD nBytes = nWidth * abs(nHeight) * 4;
    BITMAPFILEHEADER bmfh = { 0x4d42 };
    bmfh.bfOffBits = sizeof(bmfh) + sizeof(bmi);
    bmfh.bfSize = bmfh.bfOffBits + nBytes;

    HANDLE hFile = CreateFile(szFilePath, FILE_GENERIC_WRITE, 0, NULL,
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    DWORD dwBytesWritten;
    WriteFile(hFile, &bmfh, sizeof(bmfh), &dwBytesWritten, NULL);
    WriteFile(hFile, &bmi, sizeof(bmi), &dwBytesWritten, NULL);
    for (int i = nHeight - 1; i >= 0; i--) {
        WriteFile(hFile, pData + nPitch * i, nWidth * 4, &dwBytesWritten, NULL);
    }
    CloseHandle(hFile);
}

static void SaveSurfaceToBmp(IDirect3DDevice9 *pDevice, IDirect3DSurface9 *pSurface, char *szFileName) {
    D3DLOCKED_RECT lockedRect;
    RECT rect = {0, 0, 1, 1};
    if (FAILED(pSurface->LockRect(&lockedRect, &rect, 0))) {
        fprintf(stderr, "LockRect() failed.\n");
    }
    pSurface->UnlockRect();

    if (FAILED(pSurface->LockRect(&lockedRect, NULL, D3DLOCK_READONLY))) {
        fprintf(stderr, "LockRect() failed.\n");
    }
    D3DSURFACE_DESC desc;
    pSurface->GetDesc(&desc);
    SaveBmp((BYTE *)lockedRect.pBits, desc.Width, desc.Height, lockedRect.Pitch, szFileName);
    pSurface->UnlockRect();   
}

static void Save10bitSurfaceToBmp(IDirect3DDevice9 *pDevice, IDirect3DSurface9 *pSurface, char *szFileName) {
    D3DLOCKED_RECT lockedRect;
    RECT rect = { 0, 0, 1, 1 };
    if (FAILED(pSurface->LockRect(&lockedRect, &rect, 0))) {
        fprintf(stderr, "LockRect() failed.\n");
    }
    pSurface->UnlockRect();

    if (FAILED(pSurface->LockRect(&lockedRect, NULL, D3DLOCK_READONLY))) {
        fprintf(stderr, "LockRect() failed.\n");
    }
    D3DSURFACE_DESC desc;
    pSurface->GetDesc(&desc);
    BYTE *pData = new BYTE[desc.Width * desc.Height * 4];
    for (unsigned x = 0; x < desc.Width; x++) {
        for (unsigned y = 0; y < desc.Height; y++) {
            int c = ((int *)lockedRect.pBits)[y * lockedRect.Pitch / 4 + x];
            pData[y * desc.Width * 4 + x * 4 + 0] = c >> 22;
            pData[y * desc.Width * 4 + x * 4 + 1] = c >> 12;
            pData[y * desc.Width * 4 + x * 4 + 2] = c >> 2;
        }
    }
    pSurface->UnlockRect();
    SaveBmp(pData, desc.Width, desc.Height, desc.Width * 4, szFileName);
    delete pData;
}
