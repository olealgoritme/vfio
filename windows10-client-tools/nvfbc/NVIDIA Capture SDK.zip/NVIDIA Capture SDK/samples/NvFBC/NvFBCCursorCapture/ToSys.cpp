/*!
 * \cond
 * \brief
 * Demonstrates the use of NvFBCToSys to copy the desktop to system memory. 
 * This sample demonstrates the use of NvFBCToSys class to record the
 * entire desktop. It covers loading the NvFBC DLL, loading the NvFBC 
 * function pointers, creating an instance of NvFBCToSys and using it 
 * to copy the full screen frame buffer into system memory.
 *
 * \copyright
 * Copyright 1993-2018 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO LICENSEE:
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 *
 * These Licensed Deliverables contained herein is PROPRIETARY and
 * CONFIDENTIAL to NVIDIA and is being provided under the terms and
 * conditions of a form of NVIDIA software license agreement by and
 * between NVIDIA and Licensee ("License Agreement") or electronically
 * accepted by Licensee.  Notwithstanding any terms or conditions to
 * the contrary in the License Agreement, reproduction or disclosure
 * of the Licensed Deliverables to any third party without the express
 * written consent of NVIDIA is prohibited.
 *
 * NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE
 * LICENSE AGREEMENT, NVIDIA MAKES NO REPRESENTATION ABOUT THE
 * SUITABILITY OF THESE LICENSED DELIVERABLES FOR ANY PURPOSE.  IT IS
 * PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY OF ANY KIND.
 * NVIDIA DISCLAIMS ALL WARRANTIES WITH REGARD TO THESE LICENSED
 * DELIVERABLES, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY,
 * NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE
 * LICENSE AGREEMENT, IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY
 * SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THESE LICENSED DELIVERABLES.
 *
 * U.S. Government End Users.  These Licensed Deliverables are a
 * "commercial item" as that term is defined at 48 C.F.R. 2.101 (OCT
 * 1995), consisting of "commercial computer software" and "commercial
 * computer software documentation" as such terms are used in 48
 * C.F.R. 12.212 (SEPT 1995) and is provided to the U.S. Government
 * only as a commercial end item.  Consistent with 48 C.F.R.12.212 and
 * 48 C.F.R. 227.7202-1 through 227.7202-4 (JUNE 1995), all
 * U.S. Government End Users acquire the Licensed Deliverables with
 * only those rights set forth herein.
 *
 * Any use of the Licensed Deliverables in individual and commercial
 * software must include, in the user documentation and internal
 * comments to the code, the above Disclaimer and U.S. Government End
 * Users Notice.
*/

#include <windows.h>
#include <d3d9.h>
#include <stdio.h>
#include <stdlib.h>
#include <NvFBCLibrary.h>
#include <NvFBC/nvFBCToSys.h>
#include "Grabber.h"
#include "bitmap.h"

void ToSysGrabber::release()
{
    SAFE_RELEASE_2(m_pFBC,NvFBCToSysRelease);
}

bool ToSysGrabber::init() 
{ 
    if (Grabber::init()) 
    { 
        m_pFBC = (NvFBCToSys *)m_pvFBC; 
        return true;
    } 
    return false; 
}

bool ToSysGrabber::setup()
{
    if (!m_pFBC)
    {
        return false;
    }

    NVFBC_TOSYS_SETUP_PARAMS fbcSysSetupParams = { 0 };
    fbcSysSetupParams.dwVersion = NVFBC_TOSYS_SETUP_PARAMS_VER;
    fbcSysSetupParams.eMode = NVFBC_TOSYS_ARGB;
    fbcSysSetupParams.bWithHWCursor = TRUE;
    fbcSysSetupParams.bEnableSeparateCursorCapture = TRUE;
    fbcSysSetupParams.bDiffMap = FALSE;
    fbcSysSetupParams.ppBuffer = (void **)&m_pSysMemBuf;
    fbcSysSetupParams.ppDiffMap = NULL;

    NVFBCRESULT status = m_pFBC->NvFBCToSysSetUp(&fbcSysSetupParams);
    m_hCursorEvent = (HANDLE)fbcSysSetupParams.hCursorCaptureEvent;
    return (status == NVFBC_SUCCESS) ? true : false;
}

bool ToSysGrabber::grab()
{
    if (!m_pFBC)
    {
        return false;
    }

    char outName[256] = {0};
    FILE *outputFile = NULL;
    NVFBCRESULT status = NVFBC_SUCCESS;

    sprintf(outName, "NVFBC_ToSys_%d.bmp", m_uFrameNo);
    NVFBC_TOSYS_GRAB_FRAME_PARAMS fbcSysGrabParams = {0};
    NvFBCFrameGrabInfo grabInfo = {0};
    fbcSysGrabParams.dwVersion = NVFBC_TOSYS_GRAB_FRAME_PARAMS_VER;
    fbcSysGrabParams.dwFlags = NVFBC_TOSYS_NOWAIT;
    fbcSysGrabParams.pNvFBCFrameGrabInfo = &grabInfo;

    status = m_pFBC->NvFBCToSysGrabFrame(&fbcSysGrabParams);
    if (status != NVFBC_SUCCESS)
    {
        fprintf(stderr, __FUNCTION__": [%d] : Grab Failed with error %d\n", getAdapterIdx(), status);
        return false;
    }

    SaveARGB(outName, (BYTE *)m_pSysMemBuf, grabInfo.dwWidth, grabInfo.dwHeight, grabInfo.dwBufferWidth);
    fprintf (stderr, __FUNCTION__": [%d] : Grab succeeded. Wrote %s as RGB.\n", getAdapterIdx(), outName);
    return true;
}

bool ToSysGrabber::cursorCapture()
{
    if (!m_pFBC)
    {
        return false;
    }
    NVFBC_CURSOR_CAPTURE_PARAMS cursorParams;
    cursorParams.dwVersion = NVFBC_CURSOR_CAPTURE_PARAMS_VER;

    NVFBCRESULT status = NVFBC_SUCCESS;
    m_uFrameNo++;
    status = m_pFBC->NvFBCToSysCursorCapture(&cursorParams);
    if (status != NVFBC_SUCCESS)
    {
        fprintf(stderr, __FUNCTION__": [%d] : Grab Failed with error %d\n", getAdapterIdx(), status);
        return false;
    }
    CompareCursor(&cursorParams);

    return true;
}
/* !
* \endcond
*/